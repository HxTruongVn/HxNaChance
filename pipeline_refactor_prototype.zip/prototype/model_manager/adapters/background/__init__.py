# Background remover adapters
