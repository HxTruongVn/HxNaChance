"""
ISNet Background Remover Adapter.
"""
import os
import numpy as np
import torch
from capabilities.background_remover import BackgroundRemover


class ISNetRemover(BackgroundRemover):
    """
    Adapter cho ISNet.
    """

    def __init__(self):
        self.model = None
        self.device = "cpu"
        self._loaded = False

    def load(self, weight_path: str, device: str = "cpu") -> None:
        if not os.path.exists(weight_path):
            raise FileNotFoundError(f"Weight not found: {weight_path}")

        # TODO: Điều chỉnh import theo repo
        self.device = device
        self._loaded = True

    def is_loaded(self) -> bool:
        return self._loaded and self.model is not None

    def process(self, image: np.ndarray, **kwargs) -> tuple[np.ndarray, np.ndarray]:
        if not self.is_loaded():
            raise RuntimeError("Model not loaded.")

        h, w = image.shape[:2]
        # TODO: Tích hợp logic từ photo_engine.py
        # Placeholder
        alpha = np.ones((h, w), dtype=np.float32)
        rgba = np.dstack([image, (alpha * 255).astype(np.uint8)])
        return rgba, alpha

    def unload(self) -> None:
        self.model = None
        self._loaded = False
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
