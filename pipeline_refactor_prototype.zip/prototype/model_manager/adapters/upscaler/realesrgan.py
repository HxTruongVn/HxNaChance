"""
Real-ESRGAN Upscaler Adapter.
"""
import os
import numpy as np
import torch
from capabilities.upscaler import Upscaler


class RealESRGANUpscaler(Upscaler):
    """
    Adapter cho Real-ESRGAN.
    """

    def __init__(self):
        self.model = None
        self.device = "cpu"
        self._loaded = False

    def load(self, weight_path: str, device: str = "cpu") -> None:
        if not os.path.exists(weight_path):
            raise FileNotFoundError(f"Weight not found: {weight_path}")

        # TODO: Điều chỉnh import theo repo
        # from realesrgan import RealESRGANer
        # hoặc load RRDBNet trực tiếp

        self.device = device
        self._loaded = True

    def is_loaded(self) -> bool:
        return self._loaded and self.model is not None

    def process(self, image: np.ndarray, scale: int = 2, **kwargs) -> np.ndarray:
        if not self.is_loaded():
            raise RuntimeError("Model not loaded.")
        # TODO: Tích hợp logic upscale từ photo_engine.py
        return image

    def unload(self) -> None:
        self.model = None
        self._loaded = False
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
