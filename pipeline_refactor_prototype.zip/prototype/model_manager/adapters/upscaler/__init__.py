# Upscaler adapters
