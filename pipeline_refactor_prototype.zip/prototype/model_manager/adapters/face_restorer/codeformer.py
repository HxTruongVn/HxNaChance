"""
CodeFormer Face Restorer Adapter.
"""
import os
import numpy as np
import torch
import cv2
from capabilities.face_restorer import FaceRestorer


class CodeFormerRestorer(FaceRestorer):
    """
    Adapter cho CodeFormer.
    Giả định: sử dụng code hiện tại trong repo làm baseline.
    """

    def __init__(self):
        self.model = None
        self.device = "cpu"
        self._loaded = False

    def load(self, weight_path: str, device: str = "cpu") -> None:
        if not os.path.exists(weight_path):
            raise FileNotFoundError(f"Weight not found: {weight_path}")

        # TODO: Điều chỉnh import theo cấu trúc repo thực tế
        # Ví dụ:
        # from codeformer.facelib.utils import load_file_from_url
        # from codeformer.basicsr.utils import img2tensor, tensor2img
        # from codeformer.basicsr.archs.codeformer_arch import CodeFormer

        self.device = device
        # Placeholder: khởi tạo model tương tự code hiện tại
        # self.model = CodeFormer(...)
        # self.model.load_state_dict(torch.load(weight_path, map_location=device)["params_ema"])
        # self.model.to(device).eval()
        self._loaded = True

    def is_loaded(self) -> bool:
        return self._loaded and self.model is not None

    def process(self, image: np.ndarray, face_boxes: list = None, **kwargs) -> np.ndarray:
        if not self.is_loaded():
            raise RuntimeError("Model not loaded.")

        # TODO: Tích hợp logic từ photo_engine.py hiện tại
        # Đảm bảo:
        # 1. Detect face nếu face_boxes is None
        # 2. Crop từng face
        # 3. Chạy CodeFormer
        # 4. Paste ngược vào ảnh gốc
        # 5. Trả về ảnh đã phục hồi

        # Placeholder: return input unchanged
        return image

    def unload(self) -> None:
        self.model = None
        self._loaded = False
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
