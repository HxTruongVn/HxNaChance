"""
BiSeNet Face Parser Adapter.
Chuyển đổi output BiSeNet về chuẩn FaceParseResult.

Lưu ý quan trọng khi implement:
- BiSeNet output: tensor shape (1, 19, H, W) — 19 classes.
- Cần mapping class index → vùng mặt.
- Mask trả về phải là np.ndarray bool, shape (H, W).
"""
import os
import numpy as np
import torch
import torch.nn.functional as F
from capabilities.face_parser import FaceParser, FaceParseResult


# Mapping từ class index của BiSeNet sang semantic region
# Tham khảo: https://github.com/zllrunning/face-parsing.PyTorch
BISETN_CLASS_MAP = {
    1: "skin",
    2: "eyebrow",
    3: "eye",
    4: "eyeglasses",  # có thể bỏ qua nếu không cần
    5: "ear",
    6: "earring",
    7: "nose",
    8: "mouth",       # lips
    9: "teeth",
    10: "beard",
    11: "hair",
    12: "hat",
    13: "earring_2",
    14: "neck",
    15: "necklace",
    16: "clothing",
    17: "body",
    18: "background",
}


class BiSeNetFaceParser(FaceParser):
    """
    Adapter cho BiSeNet face parsing model.
    Giả định: bạn đã có module BiSeNet trong repo (copy từ code hiện tại).
    """

    def __init__(self):
        self.model = None
        self.device = "cpu"
        self._loaded = False

    def load(self, weight_path: str, device: str = "cpu") -> None:
        if not os.path.exists(weight_path):
            raise FileNotFoundError(f"Weight not found: {weight_path}")

        # Import lazy để tránh dependency khi chưa cần
        # Giả định bạn có module BiSeNet trong repo hiện tại
        try:
            from model import BiSeNet  # Điều chỉnh import path theo repo thực tế
        except ImportError:
            # Fallback: nếu chưa tách module, giữ placeholder
            raise ImportError(
                "BiSeNet model class not found. "
                "Vui lòng điều chỉnh import path trong bisenet.py adapter."
            )

        self.device = device
        self.model = BiSeNet(n_classes=19)
        self.model.load_state_dict(torch.load(weight_path, map_location=device))
        self.model.to(device)
        self.model.eval()
        self._loaded = True

    def is_loaded(self) -> bool:
        return self._loaded and self.model is not None

    def process(self, image: np.ndarray, **kwargs) -> FaceParseResult:
        """
        Args:
            image: np.ndarray (H, W, 3), RGB, uint8.
        Returns:
            FaceParseResult
        """
        if not self.is_loaded():
            raise RuntimeError("Model not loaded. Call load() first.")

        import torchvision.transforms as transforms

        # Preprocess
        h, w = image.shape[:2]
        to_tensor = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
        ])
        # Chuyển numpy → tensor
        img_tensor = to_tensor(image).unsqueeze(0).to(self.device)

        # Inference
        with torch.no_grad():
            out = self.model(img_tensor)[0]  # Giả định model trả về tuple/list
            if isinstance(out, (tuple, list)):
                out = out[0]
            # Upsample về kích thước gốc
            out = F.interpolate(out, size=(h, w), mode="bilinear", align_corners=True)
            # Lấy class prediction
            parsing = out.argmax(dim=1).squeeze(0).cpu().numpy()  # (H, W)

        # Tạo mask từng vùng
        result = FaceParseResult()
        result.skin_mask = (parsing == 1)
        result.eyebrow_mask = (parsing == 2)
        result.eye_mask = (parsing == 3)
        result.nose_mask = (parsing == 7)
        result.lip_mask = (parsing == 8)
        result.teeth_mask = (parsing == 9)
        result.hair_mask = (parsing == 11)
        result.background_mask = (parsing == 18)

        return result

    def unload(self) -> None:
        self.model = None
        self._loaded = False
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
