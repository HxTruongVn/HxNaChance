"""
ModelManager — trung tâm quản lý model runtime.
Chịu trách nhiệm: khởi tạo adapter, load weight, cung cấp instance cho Pipeline.
KHÔNG download. KHÔNG tìm Internet. Chỉ làm việc với local.
"""
from typing import Dict, Optional
from capabilities.base import Capability
from .registry import ModelRegistry


class ModelManager:
    """
    Singleton-like manager cho toàn bộ model trong app.
    
    Usage:
        manager = ModelManager("config/models.yaml")
        manager.register_all_adapters()
        
        face_parser = manager.get("face_parser")
        if face_parser and face_parser.is_loaded():
            result = face_parser.process(image)
    """

    def __init__(self, config_path: str = "config/models.yaml", device: str = "cpu"):
        self.registry = ModelRegistry(config_path)
        self.device = device
        self._instances: Dict[str, Capability] = {}

    def register_adapter(self, capability_name: str, adapter_class) -> None:
        """Đăng ký một adapter class."""
        self.registry.register_adapter(capability_name, adapter_class)

    def register_all_adapters(self) -> None:
        """
        Đăng ký toàn bộ adapter có sẵn.
        Gọi một lần khi khởi động app.
        """
        # Import lazy để tránh circular import
        from capabilities.face_parser import FaceParser
        from capabilities.face_restorer import FaceRestorer
        from capabilities.upscaler import Upscaler
        from capabilities.background_remover import BackgroundRemover

        # Đăng ký adapter cụ thể
        # TODO: Có thể dùng entry_points hoặc auto-discover sau này
        from .adapters.face_parser.bisenet import BiSeNetFaceParser
        from .adapters.face_restorer.codeformer import CodeFormerRestorer
        from .adapters.upscaler.realesrgan import RealESRGANUpscaler
        from .adapters.background.isnet import ISNetRemover

        self.register_adapter("face_parser", BiSeNetFaceParser)
        self.register_adapter("face_restorer", CodeFormerRestorer)
        self.register_adapter("upscaler", RealESRGANUpscaler)
        self.register_adapter("background_remover", ISNetRemover)

    def get(self, capability_name: str) -> Optional[Capability]:
        """
        Lấy instance adapter đã load cho một capability.
        Nếu chưa có, tự khởi tạo và load weight.
        """
        if capability_name in self._instances:
            return self._instances[capability_name]

        adapter_class = self.registry.get_adapter_class(capability_name)
        if adapter_class is None:
            print(f"[ModelManager] No adapter registered for: {capability_name}")
            return None

        weight_path = self.registry.get_weight_path(capability_name)
        if weight_path is None:
            print(f"[ModelManager] No weight configured for: {capability_name}")
            return None

        # Khởi tạo và load
        instance = adapter_class()
        try:
            instance.load(weight_path, device=self.device)
            self._instances[capability_name] = instance
            print(f"[ModelManager] Loaded {capability_name} from {weight_path}")
            return instance
        except Exception as e:
            print(f"[ModelManager] FAILED to load {capability_name}: {e}")
            return None

    def unload(self, capability_name: str) -> None:
        """Unload một capability cụ thể."""
        instance = self._instances.pop(capability_name, None)
        if instance:
            instance.unload()

    def unload_all(self) -> None:
        """Unload toàn bộ model."""
        for name, instance in list(self._instances.items()):
            instance.unload()
        self._instances.clear()

    def is_available(self, capability_name: str) -> bool:
        """Kiểm tra capability có sẵn sàng không (đã load thành công)."""
        instance = self._instances.get(capability_name)
        return instance is not None and instance.is_loaded()

    def get_runtime_report(self) -> Dict:
        """Báo cáo trạng thái tất cả capability."""
        report = {}
        for cap_name in self.registry.list_capabilities():
            instance = self._instances.get(cap_name)
            report[cap_name] = {
                "configured": self.registry.is_capability_configured(cap_name),
                "adapter_registered": self.registry.get_adapter_class(cap_name) is not None,
                "loaded": instance.is_loaded() if instance else False,
            }
        return report
