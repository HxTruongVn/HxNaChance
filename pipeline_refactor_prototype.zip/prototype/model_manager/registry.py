"""
ModelRegistry — đọc cấu hình từ YAML và ánh xạ capability → adapter class.
Không chứa logic xử lý ảnh. Chỉ là 'bản đồ'.
"""
import yaml
import os
from typing import Dict, Type, Optional
from capabilities.base import Capability


class ModelRegistry:
    """
    Đọc config/models.yaml và cung cấp thông tin:
    - Capability nào dùng provider nào
    - Adapter class nào
    - Weight file nào
    - Version bao nhiêu
    """

    def __init__(self, config_path: str = "config/models.yaml"):
        self.config_path = config_path
        self._config: Dict = {}
        self._adapters: Dict[str, Type[Capability]] = {}
        self._load_config()

    def _load_config(self) -> None:
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Model config not found: {self.config_path}")
        with open(self.config_path, "r", encoding="utf-8") as f:
            self._config = yaml.safe_load(f)

    def register_adapter(self, capability_name: str, adapter_class: Type[Capability]) -> None:
        """
        Đăng ký adapter class cho một capability.
        Gọi trong __init__ của ModelManager.
        """
        self._adapters[capability_name] = adapter_class

    def get_capability_config(self, capability_name: str) -> Optional[Dict]:
        """Lấy config của một capability từ YAML."""
        return self._config.get(capability_name)

    def get_adapter_class(self, capability_name: str) -> Optional[Type[Capability]]:
        """Lấy adapter class đã đăng ký."""
        return self._adapters.get(capability_name)

    def get_weight_path(self, capability_name: str) -> Optional[str]:
        """Lấy đường dẫn weight từ config."""
        cfg = self._config.get(capability_name)
        if not cfg:
            return None
        weight = cfg.get("weight")
        if not weight:
            return None
        # Hỗ trợ đường dẫn tương đối từ thư mục models_data/
        if not os.path.isabs(weight):
            weight = os.path.join("models_data", cfg.get("category", ""), weight)
        return weight

    def list_capabilities(self) -> list:
        """Liệt kê tất cả capability trong config."""
        return list(self._config.keys())

    def is_capability_configured(self, capability_name: str) -> bool:
        """Kiểm tra capability có trong config không."""
        return capability_name in self._config
