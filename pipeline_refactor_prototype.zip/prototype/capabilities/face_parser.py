"""
FaceParser Capability — Interface chuẩn cho mọi model face parsing.
"""
from abc import abstractmethod
from dataclasses import dataclass
from typing import Optional
import numpy as np
from .base import Capability


@dataclass
class FaceParseResult:
    """
    Chuẩn hóa output face parsing.
    Mọi adapter (BiSeNet, SegFormer, ...) phải trả về object này.
    
    Mỗi mask là np.ndarray shape (H, W), dtype bool.
    """
    skin_mask: Optional[np.ndarray] = None
    eye_mask: Optional[np.ndarray] = None
    eyebrow_mask: Optional[np.ndarray] = None
    nose_mask: Optional[np.ndarray] = None
    lip_mask: Optional[np.ndarray] = None
    teeth_mask: Optional[np.ndarray] = None
    hair_mask: Optional[np.ndarray] = None
    background_mask: Optional[np.ndarray] = None

    def get_combined_face_mask(self) -> Optional[np.ndarray]:
        """Trả về mask toàn bộ khuôn mặt (trừ background)."""
        masks = [
            self.skin_mask, self.eye_mask, self.eyebrow_mask,
            self.nose_mask, self.lip_mask, self.teeth_mask, self.hair_mask
        ]
        valid = [m for m in masks if m is not None]
        if not valid:
            return None
        combined = np.zeros_like(valid[0], dtype=bool)
        for m in valid:
            combined |= m
        return combined


class FaceParser(Capability):
    """
    Capability: Phân tích vùng khuôn mặt.
    """

    @property
    def name(self) -> str:
        return "face_parser"

    @abstractmethod
    def load(self, weight_path: str, device: str = "cpu") -> None:
        pass

    @abstractmethod
    def is_loaded(self) -> bool:
        pass

    @abstractmethod
    def process(self, image: np.ndarray, **kwargs) -> FaceParseResult:
        """
        Args:
            image: np.ndarray (H, W, 3), BGR hoặc RGB tùy convention.
        Returns:
            FaceParseResult với các mask vùng mặt.
        """
        pass

    @abstractmethod
    def unload(self) -> None:
        pass
