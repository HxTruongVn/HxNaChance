"""
Base class cho mọi Capability trong hệ thống.
Mọi adapter phải kế thừa từ Capability base tương ứng.
"""
from abc import ABC, abstractmethod
from typing import Any


class Capability(ABC):
    """
    Capability là 'hợp đồng' giữa Pipeline và Model.
    Pipeline chỉ biết Capability, không biết model cụ thể.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Tên capability, ví dụ: 'face_parser', 'face_restorer'."""
        pass

    @abstractmethod
    def load(self, weight_path: str, device: str = "cpu") -> None:
        """Load model weight. Phải gọi trước khi process."""
        pass

    @abstractmethod
    def is_loaded(self) -> bool:
        """Kiểm tra model đã load thành công chưa."""
        pass

    @abstractmethod
    def process(self, image: Any, **kwargs) -> Any:
        """Xử lý ảnh. Tham số và return type do từng capability con định nghĩa."""
        pass

    @abstractmethod
    def unload(self) -> None:
        """Giải phóng bộ nhớ nếu cần."""
        pass
