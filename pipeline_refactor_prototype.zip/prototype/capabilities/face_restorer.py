"""
FaceRestorer Capability — Interface chuẩn cho model phục hồi khuôn mặt.
"""
from abc import abstractmethod
import numpy as np
from .base import Capability


class FaceRestorer(Capability):
    """
    Capability: Phục hồi/làm nét khuôn mặt.
    Ví dụ: CodeFormer, GFPGAN.
    """

    @property
    def name(self) -> str:
        return "face_restorer"

    @abstractmethod
    def load(self, weight_path: str, device: str = "cpu") -> None:
        pass

    @abstractmethod
    def is_loaded(self) -> bool:
        pass

    @abstractmethod
    def process(self, image: np.ndarray, face_boxes: list = None, **kwargs) -> np.ndarray:
        """
        Args:
            image: np.ndarray (H, W, 3).
            face_boxes: List of (x1, y1, x2, y2) — tùy chọn.
        Returns:
            Ảnh đã phục hồi, cùng shape với input.
        """
        pass

    @abstractmethod
    def unload(self) -> None:
        pass
