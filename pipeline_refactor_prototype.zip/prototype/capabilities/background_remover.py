"""
BackgroundRemover Capability — Interface chuẩn cho model tách nền.
"""
from abc import abstractmethod
import numpy as np
from .base import Capability


class BackgroundRemover(Capability):
    """
    Capability: Tách/xóa nền ảnh.
    Ví dụ: ISNet, U2Net.
    """

    @property
    def name(self) -> str:
        return "background_remover"

    @abstractmethod
    def load(self, weight_path: str, device: str = "cpu") -> None:
        pass

    @abstractmethod
    def is_loaded(self) -> bool:
        pass

    @abstractmethod
    def process(self, image: np.ndarray, **kwargs) -> tuple[np.ndarray, np.ndarray]:
        """
        Args:
            image: np.ndarray (H, W, 3).
        Returns:
            (foreground_rgba, alpha_mask).
            foreground_rgba: np.ndarray (H, W, 4).
            alpha_mask: np.ndarray (H, W), dtype float32 [0,1].
        """
        pass

    @abstractmethod
    def unload(self) -> None:
        pass
