"""
Upscaler Capability — Interface chuẩn cho model upscale ảnh.
"""
from abc import abstractmethod
import numpy as np
from .base import Capability


class Upscaler(Capability):
    """
    Capability: Tăng độ phân giải ảnh.
    Ví dụ: Real-ESRGAN, SwinIR.
    """

    @property
    def name(self) -> str:
        return "upscaler"

    @abstractmethod
    def load(self, weight_path: str, device: str = "cpu") -> None:
        pass

    @abstractmethod
    def is_loaded(self) -> bool:
        pass

    @abstractmethod
    def process(self, image: np.ndarray, scale: int = 2, **kwargs) -> np.ndarray:
        """
        Args:
            image: np.ndarray (H, W, 3).
            scale: Hệ số upscale (2, 4, ...).
        Returns:
            Ảnh upscaled.
        """
        pass

    @abstractmethod
    def unload(self) -> None:
        pass
