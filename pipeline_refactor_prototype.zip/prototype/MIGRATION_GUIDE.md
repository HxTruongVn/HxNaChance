# Hướng dẫn chuyển đổi từ code hiện tại sang kiến trúc mới

> Hướng dẫn từng bước để refactor `photo_engine.py` mà không làm app bị hỏng.

---

## Bước 0: Backup

```bash
cp photo_engine.py photo_engine_legacy.py
cp runtime_manager.py runtime_manager_legacy.py
```

Nếu refactor lỗi, bạn luôn có thể `git checkout` hoặc copy ngược lại.

---

## Bước 1: Tạo thư mục `capabilities/`

Copy toàn bộ file trong folder `capabilities/` của prototype vào repo.

Không cần sửa gì thêm — đây chỉ là interface, chưa ảnh hưởng code cũ.

---

## Bước 2: Tạo BiSeNet Adapter (Milestone A)

### 2.1. Tạo `model_manager/adapters/face_parser/bisenet.py`

- Copy prototype vào.
- **Sửa phần import `from model import BiSeNet`** cho đúng với repo của bạn.
- Copy logic preprocess/postprocess từ `photo_engine.py` hiện tại vào method `process()`.

### 2.2. Test adapter độc lập

Viết script test riêng, KHÔNG đụng đến `photo_engine.py`:

```python
# test_adapter.py
import cv2
from model_manager.adapters.face_parser.bisenet import BiSeNetFaceParser

adapter = BiSeNetFaceParser()
adapter.load("models_data/face_parser/79999_iter.pth", device="cpu")

img = cv2.imread("test.jpg")
img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

result = adapter.process(img_rgb)
print(result.skin_mask.shape)  # (H, W)
print(result.eye_mask.any())   # True nếu có mắt
```

Chạy được → Milestone A 50%.

### 2.3. Sửa `photo_engine.py` — chỉ phần face parsing

**Trước** (code cũ):
```python
from model import BiSeNet
...
self.bisenet = BiSeNet(n_classes=19)
self.bisenet.load_state_dict(torch.load("models_data/face_parser/79999_iter.pth"))
...
parsing = self.bisenet(img)
```

**Sau** (dùng adapter):
```python
from model_manager.manager import ModelManager
...
# Trong __init__ của PhotoEngine
self.model_manager = ModelManager("config/models.yaml", device=self.device)
self.model_manager.register_all_adapters()
...
# Trong method xử lý face parsing
face_parser = self.model_manager.get("face_parser")
if face_parser and face_parser.is_loaded():
    result = face_parser.process(img_rgb)
    skin_mask = result.skin_mask
    eye_mask = result.eye_mask
    # ... tiếp tục logic cũ
```

**Quan trọng**: Giữ nguyên logic xử lý mask (skin, eye, teeth, hair) — chỉ thay đổi **cách lấy mask**.

### 2.4. Chạy thử toàn bộ app

Nếu app chạy được như cũ → Milestone A hoàn thành.

---

## Bước 3: Chuyển CodeFormer (Milestone B bắt đầu)

Tương tự BiSeNet:

1. Tạo `model_manager/adapters/face_restorer/codeformer.py`.
2. Copy logic CodeFormer từ `photo_engine.py` vào `process()`.
3. Sửa `photo_engine.py` để gọi `model_manager.get("face_restorer")`.

**Mẹo**: CodeFormer hay crash nhất. Hãy **try/except** quanh `process()` trong adapter:

```python
def process(self, image, face_boxes=None, **kwargs):
    try:
        # logic cũ
        return restored_image
    except Exception as e:
        print(f"[CodeFormer] Failed: {e}")
        return image  # fallback: trả về ảnh gốc
```

---

## Bước 4: Chuyển RealESRGAN và ISNet

Lặp lại pattern ở Bước 2 và 3.

---

## Bước 5: Tạo `config/models.yaml`

```yaml
face_parser:
  provider: bisenet
  category: face_parser
  adapter: bisenet_face_parser
  weight: "79999_iter.pth"

face_restorer:
  provider: codeformer
  category: face_restore
  adapter: codeformer_face_restorer
  weight: "codeformer.pth"

upscaler:
  provider: realesrgan
  category: upscaler
  adapter: realesrgan_upscaler
  weight: "RealESRGAN_x2plus.pth"

background_remover:
  provider: isnet
  category: background
  adapter: isnet_background_remover
  weight: "isnet.pth"
```

Sửa `weight` cho đúng tên file trong `models_data/` của bạn.

---

## Bước 6: Tách Runtime (Milestone C)

### 6.1. Tạo `runtime/installation_manifest.json`

Sau khi `setup_models.py` chạy xong, tạo file này:

```json
{
  "face_parser": {
    "provider": "bisenet",
    "version": "1.0",
    "weight": "79999_iter.pth",
    "installed_at": "2026-07-28"
  },
  "face_restorer": {
    "provider": "codeformer",
    "version": "1.0",
    "weight": "codeformer.pth",
    "installed_at": "2026-07-28"
  }
}
```

### 6.2. Sửa `runtime_manager.py`

- Xóa toàn bộ code **download**.
- Chỉ giữ lại: đọc manifest, kiểm tra file tồn tại, báo cáo trạng thái.
- `ModelManager.get_runtime_report()` đã có sẵn logic báo cáo.

---

## Bước 7: Dọn dẹp

Sau khi Milestone C ổn định:

```bash
rm photo_engine_legacy.py
rm runtime_manager_legacy.py
```

Xóa các import trực tiếp model khỏi `photo_engine.py`:
- `from model import BiSeNet`
- `import codeformer`
- `import realesrgan`
- ...

`photo_engine.py` lúc này chỉ còn import:
- `cv2`, `numpy`, `torch` (nếu cần xử lý tensor)
- `model_manager.manager.ModelManager`
- `capabilities.face_parser.FaceParseResult`

---

## Checklist hoàn thành

- [ ] BiSeNet chạy qua adapter, app không crash
- [ ] CodeFormer chạy qua adapter
- [ ] RealESRGAN chạy qua adapter
- [ ] ISNet chạy qua adapter
- [ ] `photo_engine.py` không còn import model cụ thể
- [ ] `config/models.yaml` tồn tại và đọc được
- [ ] Ngắt Internet, app vẫn chạy
- [ ] Thiếu weight → capability bị disable, app vẫn chạy (không crash)

---

*Chúc bạn refactor thành công!*
