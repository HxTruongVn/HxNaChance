# Gợi ý thực hiện Plan.md — Photo Master Pro

> Bản tóm tắt này được tạo để hỗ trợ tác giả repo `HxTruongVn/pipeline` triển khai kiến trúc mới một cách thực tế, tránh over-engineering và burnout giữa chừng.

---

## 1. Chiến lược cắt nhỏ — "Mỗi Milestone phải chạy được"

Đừng refactor 10 giai đoạn liền một mạch. Hãy chia thành **4 Milestone**, mỗi milestone là một bản release ổn định:

### Milestone A: "BiSeNet qua Adapter" (1–1.5 tuần)
**Mục tiêu**: Chứng minh kiến trúc Adapter hoạt động với 1 model duy nhất.
- Tạo `FaceParser` interface (abc.ABC).
- Tạo `BiSeNetFaceParser` adapter.
- `PhotoEngine` gọi `FaceParser.parse()` thay vì `BiSeNet()` trực tiếp.
- **Không đụng đến CodeFormer, RealESRGAN, ISNet**.
- **Không cần Model Registry phức tạp** — dùng dict đơn giản.

**Dấu hiệu hoàn thành**: 
- Swap `BiSeNetFaceParser` → mock parser trả về mask giả, pipeline vẫn chạy không crash.

### Milestone B: "Capability đầy đủ" (1.5–2 tuần)
**Mục tiêu**: Tất cả model còn lại đều có adapter.
- `FaceRestorer` interface + `CodeFormerRestorer` adapter.
- `Upscaler` interface + `RealESRGANUpscaler` adapter.
- `BackgroundRemover` interface + `ISNetRemover` adapter.
- `PhotoEngine` chỉ còn biết các Capability, không còn import model cụ thể.

**Dấu hiệu hoàn thành**:
- Xóa hết import `import codeformer`, `import realesrgan`, `import bisenet` khỏi `photo_engine.py`.

### Milestone C: "Model Registry + Runtime tách biệt" (1 tuần)
**Mục tiêu**: Setup và Runtime không còn lẫn lộn.
- `models.yaml` định nghĩa model nào dùng adapter nào, weight nào.
- `ModelManager` đọc `models.yaml`, khởi tạo adapter tương ứng.
- `RuntimeManager` chỉ đọc manifest và báo cáo — không download, không tìm Internet.
- `setup_models.py` chỉ chạy ở phase setup, tạo `installation_manifest.json`.

**Dấu hiệu hoàn thành**:
- Sau khi setup xong, xóa toàn bộ code download khỏi `runtime_manager.py`.
- Ngắt Internet, app vẫn chạy.

### Milestone D: "Discovery + Compatibility" (tùy chọn, 1–2 tuần)
**Mục tiêu**: Thông minh hóa việc tìm model.
- Multi-source discovery (GitHub → HuggingFace → Mirror).
- Compatibility check cơ bản (task + framework + output shape).
- Hash verify khi download.

**Lưu ý**: Milestone này là "nice-to-have". Nếu thấy mệt sau Milestone C, hãy dừng lại. App đã đủ tốt.

---

## 2. Thứ tự ưu tiên code

| Ưu tiên | File cần viết | Lý do |
|---------|--------------|-------|
| 1 | `capabilities/face_parser.py` (interface) | BiSeNet là model phức tạp nhất về output (19 classes). Làm xong interface này, các model khác dễ hơn. |
| 2 | `model_manager/adapters/bisenet.py` | Proof of concept cho cả hệ thống. |
| 3 | `capabilities/face_restorer.py` + `codeformer.py` adapter | CodeFormer hiện đang gây crash nhiều nhất, cần cô lập. |
| 4 | `model_manager/registry.py` | Chỉ cần đọc YAML và ánh xạ `capability → adapter class`. Đơn giản. |
| 5 | `runtime/installation_manifest.json` + `runtime_manager.py` mới | Tách setup khỏi runtime. |
| 6 | `setup/model_discovery.py` | Nếu còn thở sau 5 bước trên. |

---

## 3. Cạm bẫy cần tránh (dựa trên phân tích codebase)

### ❌ Đừng viết interface quá sớm cho tất cả model
Plan.md đề xuất 10 giai đoạn, nhưng nếu bạn ngồi viết interface cho `Upscaler`, `BackgroundRemover`, `FaceAlign` trước khi BiSeNet chạy qua adapter, bạn sẽ **đoán sai** shape và API. Hãy làm **từng model một**, rút kinh nghiệm rồi tổng quát hóa.

### ❌ Đừng cố gắng chuẩn hóa `FaceParseResult` hoàn hảo ngay lần đầu
BiSeNet trả về tensor `(1, 19, H, W)`. Bạn không cần map đủ 19 classes ngay. Hãy bắt đầu với:
```python
class FaceParseResult:
    skin_mask: np.ndarray
    eye_mask: np.ndarray
    teeth_mask: np.ndarray
    hair_mask: np.ndarray
```
Sau khi chạy ổn, mở rộng thêm `eyebrow`, `nose`, `lips`.

### ❌ Đừng để AI (Claude/Cursor) viết toàn bộ adapter
Adapter cần hiểu sâu output của model. AI có thể viết code "nhìn đúng" nhưng mask shape sai `(H, W)` vs `(W, H)`, dtype `uint8` vs `bool`. **Hãy tự viết phần `forward()` và `postprocess()` của adapter**, AI chỉ hỗ trợ boilerplate.

### ❌ Đừng xóa code cũ ngay
Trong quá trình refactor, giữ `photo_engine.py` gốc thành `photo_engine_legacy.py`. Khi adapter bị lỗi, bạn còn có thể diff để so sánh.

### ❌ Đừng thêm pytest phức tạp ngay
Milestone A–C chỉ cần **smoke test**: load model, chạy 1 ảnh, assert không crash. Đừng viết mock cho `nn.Module` — tốn thở giờ, dễ nản.

---

## 4. Gợi ý cấu trúc thư mục tối thiểu (Milestone A–C)

```
pipeline/
├── app/
│   ├── main.py
│   ├── main_ui.py
│   └── photo_engine.py          # chỉ còn gọi Capability
├── capabilities/
│   ├── __init__.py
│   ├── base.py                  # Capability base class
│   ├── face_parser.py           # FaceParser interface
│   ├── face_restorer.py         # FaceRestorer interface
│   ├── upscaler.py              # Upscaler interface
│   └── background_remover.py    # BackgroundRemover interface
├── model_manager/
│   ├── __init__.py
│   ├── registry.py              # đọc models.yaml
│   ├── manager.py               # get(capability_name) → adapter instance
│   └── adapters/
│       ├── __init__.py
│       ├── face_parser/
│       │   └── bisenet.py
│       ├── face_restorer/
│       │   └── codeformer.py
│       ├── upscaler/
│       │   └── realesrgan.py
│       └── background/
│           └── isnet.py
├── setup/
│   ├── setup_environment.py
│   ├── model_discovery.py       # (Milestone D)
│   └── installer.py
├── runtime/
│   ├── runtime_manager.py       # chỉ đọc manifest, không download
│   └── installation_manifest.json
├── config/
│   └── models.yaml
└── models_data/                 # giữ nguyên cấu trúc cũ
```

---

## 5. Dự đoán timeline thực tế

| Kịch bản | Milestone A | Milestone B | Milestone C | Milestone D |
|----------|-------------|-------------|-------------|-------------|
| **Full-time burst** (như tuần vừa rồi) | 5–7 ngày | 7–10 ngày | 5 ngày | 7–10 ngày |
| **Side project** (2–3h/ngày) | 2–3 tuần | 3–4 tuần | 2 tuần | 3–4 tuần |

> **Khuyến nghị**: Nếu bạn đang ở "burst mode", hãy tận dụng để xong Milestone A và B. Đó là phần quan trọng nhất. Milestone C và D có thể làm chậm rãi sau.

---

## 6. Lợi ích từng Milestone (để không nản giữa chừng)

- **Milestone A xong**: Bạn đã có kiến trúc "đẹp" chạy được. Cảm giác thành tựu cao.
- **Milestone B xong**: `PhotoEngine` sạch hoàn toàn. Code nhìn professional.
- **Milestone C xong**: Ứng dụng offline ổn định. Có thể đem đi triển khai tiệm ảnh.
- **Milestone D xong**: Dễ dàng thêm model mới chỉ bằng cách thêm file adapter + sửa YAML.

---

*Được tạo ngày 2026-07-28 để hỗ trợ phát triển repo pipeline.*
